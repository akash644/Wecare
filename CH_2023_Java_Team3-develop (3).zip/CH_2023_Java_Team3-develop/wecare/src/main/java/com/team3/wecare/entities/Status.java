package com.team3.wecare.entities;

public enum Status {
	WAITING, OPEN, IN_PROGRESS, CLOSED
}
